package com.niit.shoppingbackend;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.model.Product;

public class ProductTest {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart");
		context.refresh();

		ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");

		Product product = (Product) context.getBean("product");

		product.setId("C1230");
		product.setName("CNAME120");
		product.setDescription("CDES120");
		product.setPrice(1000);

		productDAO.saveOrUpdate(product);

		// System.out.println(" no of product is " + productDAO.list().size() );
	}
}
