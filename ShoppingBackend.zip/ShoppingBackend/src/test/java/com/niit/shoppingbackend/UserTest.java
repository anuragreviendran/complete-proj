package com.niit.shoppingbackend;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.User;

public class UserTest {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart");
		context.refresh();

		UserDAO userDAO = (UserDAO) context.getBean("userDAO");

		User user = (User) context.getBean("user");

		user.setId("U180");
		user.setName("UNAME150");
		user.setPassword("123D");
		user.setMobile("886759112");
		user.setEmail("aa@mail.com");
		user.setAddress("eeqqqe");

		userDAO.saveOrUpdate(user);

		// System.out.println(" no of users is " + userDAO.list().size() );

		// userDAO.isValidUser("C140", "123D");
	}
}
