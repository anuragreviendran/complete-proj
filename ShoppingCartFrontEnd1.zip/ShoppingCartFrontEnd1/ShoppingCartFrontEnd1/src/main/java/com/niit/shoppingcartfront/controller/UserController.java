package com.niit.shoppingcartfront.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.CartDAO;
import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.Cart;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.User;

@Controller
public class UserController {
	@Autowired
	private Cart cart;

	@Autowired
	private CartDAO cartDAO;

	@Autowired
	Category category;

	@Autowired
	CategoryDAO categoryDAO;

	@Autowired
	UserDAO userDAO;

	@Autowired
	User user;

	@RequestMapping("/")
	public ModelAndView onLoad(HttpSession session) {

		ModelAndView mv = new ModelAndView("/index");
		session.setAttribute("category", category);
		session.setAttribute("categoryList", categoryDAO.list());
		return mv;

	}

	@RequestMapping("/login")
	public String getLogin() {
		return "login";
	}
	
	@RequestMapping("/checkout")
	public String getcheckout() {
		return "checkout";
	}
	
	@RequestMapping("/payment")
	public String getpay()
	{
		return "payment";	
	}
	
	@RequestMapping("/list")
	public String getlist() {
		return "list";
	}
	// @RequestMapping("/admiHome")
	// public String getAdmin() {
	// return "adminHome";
	// }

	  @RequestMapping(value = "/user")
	    public String userManagement() 
	    {
	    	System.out.println("USER CALLED.......");
	    	return "login";
	    }
	    
	    @RequestMapping(value = "/admin")
	    public String adminManagement() 
	    {
	    	System.out.println("ADMIN CALLED.......");
	    	return "adminHome";
	    }
	  
	@RequestMapping(value = "/loginUser")
    public String login(@RequestParam(value="error", required = false) String error, @RequestParam(value="logout",
            required = false) String logout, Model model) {
        if (error!=null) {
        	System.out.println("Error.....");
            model.addAttribute("error", "...Invalid username and password");
        }
        	
        if(logout!=null) {
        	System.out.println("Logout called.....");
            model.addAttribute("msg", "...You have been logged out");
        }

        return "login";
    }
    
//	@RequestMapping("/check")
//	public ModelAndView login(@RequestParam(name = "name") String name,
//			@RequestParam(name = "password") String password) {
//		ModelAndView mv;
//
//		boolean isValidUser = userDAO.isValidUser(name, password);
//
//		if (isValidUser) {
//
//			user = userDAO.getUser(name);
//			if (user.getAdmin() == true) {
//				mv = new ModelAndView("/adminHome");
//				mv.addObject("message", "welcome admin" + user.getName());
//			} else {
//				mv = new ModelAndView("/Test");
//				mv.addObject("message", "welcome " + user.getName());
//			}
//		} else {
//			mv = new ModelAndView("/fail");
//			mv.addObject("message", "Invalid user");
//		}
//		return mv;
//	}

}
